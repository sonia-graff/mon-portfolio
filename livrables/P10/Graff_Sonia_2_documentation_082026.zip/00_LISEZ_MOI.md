# Livrable 2 — Documentation de la démarche

**Projet 11 · Bottleneck — Mission 1** · Sonia Graff · juillet 2026
Amélioration critique et documentée du notebook du Projet 6 grâce à l'IA.
Période de réalisation : 1er – 20 juillet 2026.

---

## Par où commencer

**Ouvrir `P11_Bottleneck_Documentation_FINAL.pdf`** — 65 pages, il consolide les
sept documents numérotés dans l'ordre de lecture, suivis du mémo, avec des signets
de navigation.

Le dossier `docs/` contient les mêmes documents en fichiers séparés, pour retrouver
une preuve sans faire défiler l'ensemble.

## Contenu

```
P11_Bottleneck_Documentation_FINAL.pdf      le dossier documentaire en un seul fichier
00_LISEZ_MOI.md                             ce fichier
docs/
  00_Index_de_conformite.docx               où se trouve chaque preuve
  01_Veille_metier_et_technologique.docx    options comparées, critères, sources
  02_Cahier_des_charges_fonctionnel.docx    besoin, périmètre, exigences F1–F17
  03_Pilotage_et_journal_IA.docx            lots, backlog, planning, risques, journal IA
  03b_Gantt_et_backlog.xlsx                 le planning et le backlog sous forme calculée
  03c_Journal_IA_modele.xlsx                la matrice de journalisation, prête à l'emploi
  04_Documentation_de_la_demarche.docx      hypothèses, tests, résultats, limites, décisions
  05_Guide_methodologique_et_mode_emploi.docx  comment le notebook fonctionne et se relance
  06_Mini_plan_de_formation.docx            appropriation par les utilisateurs métier
  06b_Memo_lecture_des_alertes.docx         le mémo d'une page remis en séance
  07_Synthese_recruteur_client.docx         le projet en deux pages, sans jargon
```

Le PDF consolidé regroupe les documents numérotés 00 à 06b. La synthèse 07 s'adresse
à un lecteur extérieur au jury : elle reste un fichier autonome, à lire seule.

## Où trouver ce que le brief demande

| Attendu | Où |
|---|---|
| Veille métier et technologique | Document 01 |
| Cahier des charges fonctionnel | Document 02 |
| Mini-formation pour les métiers | Document 06 · mémo 06b |
| Hypothèses | Document 04, §2 |
| Tests et résultats | Document 04, §3 et §7 |
| Limites | Document 04, §8 |
| Décisions | Document 04, §5 |
| Traçabilité de l'IA (prompts, variantes, décisions) | Document 03, §7 — six fiches |
| Gestion de projet (lots, backlog, planning, risques) | Document 03, §1 à §5 · classeur 03b |
| Matrice de journalisation pour les projets suivants | Document 03, §7.3 · classeur 03c |
| Reproductibilité (environnement, versions, graine) | Document 04, §9 |
| Synthèse recruteur / client | Document 07 · repris du document 04, §10 |

## Les améliorations réalisées

- **Validation centralisée** : POC Pandera / Great Expectations sur les mêmes 10 règles
  ERP, puis Pandera appliqué à l'ERP, au Web et à la liaison.
- **Rapport qualité unique** distinguant erreurs bloquantes, erreurs métier et alertes.
- **Nettoyage** : deux variantes comparées sur les stocks négatifs, solution hybride et
  traçable retenue.
- **Jointures protégées** : contrôle d'unicité, `validate=`, indicateur de fusion,
  vérification des volumes.
- **Détection d'atypiques** : IQR / Z-score / Isolation Forest comparés ; Isolation Forest
  reste un POC exploratoire, l'IQR demeure la méthode de décision.
- **Visualisation** : Matplotlib / Plotly comparés, double restitution statique et interactive.
- **Analyse exploratoire** : profiling automatisé en complément de l'EDA manuelle.
- **Restitution** : rapport HTML métier, classeur Excel multi-onglets, plan d'action et
  mini-formation accessible.

## Résultats de référence

| Contrôle | Résultat |
|---|---|
| ERP / Web / liaison | 825 / 1 513 / 825 lignes |
| Web produit / SKU exploitables | 716 / 714 |
| Dataset final | 825 lignes, 825 `product_id` uniques |
| POC Pandera / Great Expectations | 14 occurrences ERP pour les deux outils |
| Qualité brute | ERP 14 · Web 9 · liaison 91 |
| Prix atypiques | IQR 36 · Z-score 17 · Isolation Forest 17 |
| Recouvrement IQR ∩ IF | 8 communs · Jaccard 0,18 · 9 propres au multivarié |
| Marges négatives finales | 4, dont 1 exposée Web |
| Produits prioritaires | 189 — P1 4 · P2 38 · P3 147 |

## Deux principes tenus sur tout le projet

**Aucune correction automatique.** Le notebook détecte, qualifie et signale. Une marge
négative peut être un déstockage volontaire : c'est une alerte, pas une erreur. La
décision reste humaine.

**En cas de contradiction entre deux documents, c'est le notebook qui fait foi.** Il
porte les chiffres exécutés ; les documents les commentent.

## Transparence sur l'usage de l'IA

L'IA a servi d'assistant de réflexion, de code et de documentation — jamais de pilote.
Chaque proposition a été exécutée sur les données réelles, comparée à une variante, puis
retenue ou écartée selon un critère posé avant le test.

Le jeu pédagogique ne contient que des données produit et aucune donnée personnelle
identifiée. Les fichiers nécessaires ont été partagés avec les assistants ; l'exécution du
notebook est restée locale. Les échanges historiques n'ayant pas tous été archivés mot pour mot, le
journal les présente comme **prompts reconstitués** — cohérents avec le notebook initial,
les variantes testées et les décisions visibles dans la version finale, mais non présentés
comme des verbatims.

---

Sonia Graff · Projet 11 · juillet 2026
